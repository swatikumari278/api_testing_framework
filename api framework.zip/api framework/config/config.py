BASE_URL = "https://gorest.co.in/public/v2"
API_TOKEN = "77f8486c986e311fb296573510e84bddee6be5618db47bdf3fa88f1039a08629"
HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}
