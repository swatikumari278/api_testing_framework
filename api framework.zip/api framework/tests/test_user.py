import pytest

@pytest.mark.order(1)
def test_create_user(api_client):
    payload = {
        "name": "Swati Kumari",
        "email": "swati123455@example.com",  # must be unique
        "gender": "male",
        "status": "active"
    }
    response = api_client.post("/users", payload)
    assert response.status_code == 201
    global user_id
    user_id = response.json()['id']  # store for update/delete

@pytest.mark.order(2)
def test_get_user_list(api_client):
    response = api_client.get("/users")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

@pytest.mark.order(3)
def test_update_user(api_client):
    payload = {
        "name": "Swati Kumari Updated",
        "status": "inactive"
    }
    response = api_client.put(f"/users/{user_id}", payload)
    assert response.status_code == 200
    assert response.json()['status'] == "inactive"

@pytest.mark.order(4)
def test_delete_user(api_client):
    response = api_client.delete(f"/users/{user_id}")
    assert response.status_code == 204
