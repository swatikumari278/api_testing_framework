import requests
from config.config import BASE_URL, HEADERS

class APIClient:
    def __init__(self):
        self.base_url = BASE_URL
        self.headers = HEADERS

    def get(self, endpoint):
        return requests.get(f"{self.base_url}{endpoint}", headers=self.headers)

    def post(self, endpoint, data):
        return requests.post(f"{self.base_url}{endpoint}", json=data, headers=self.headers)

    def put(self, endpoint, data):
        return requests.put(f"{self.base_url}{endpoint}", json=data, headers=self.headers)

    def delete(self, endpoint):
        return requests.delete(f"{self.base_url}{endpoint}", headers=self.headers)
